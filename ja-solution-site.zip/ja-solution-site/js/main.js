'use strict';
/* Edit this: the form opens the visitor's email app addressed to it. */
var EMAIL="hello@jasolution.com";

/* Logo: drop your file into assets/images/ named logo.svg, logo.png, logo.webp or logo.jpg.
   It is detected automatically and shown unchanged. The text wordmark shows until then. */
(function(){
var names=['logo.svg','logo.png','logo.webp','logo.jpg'],base='assets/images/';
function tryNext(i){
 if(i>=names.length)return;
 var im=new Image();
 im.onload=function(){
  document.querySelectorAll('.logo').forEach(function(a){
   var c=im.cloneNode();c.alt='JA Solution';c.decoding='async';
   c.width=im.naturalWidth;c.height=im.naturalHeight;a.replaceChildren(c);
  });
 };
 im.onerror=function(){tryNext(i+1)};
 im.src=base+names[i];
}
tryNext(0);
})();

document.getElementById("y").textContent=new Date().getFullYear();
document.getElementById("f").addEventListener("submit",function(e){
e.preventDefault();var d=new FormData(e.target);
var body="Name: "+d.get("name")+"\nBusiness: "+d.get("biz")+"\nContact: "+d.get("contact")+"\nService: "+d.get("svc")+"\nGoals: "+(d.get("note")||"-");
location.href="mailto:"+EMAIL+"?subject="+encodeURIComponent("Free Marketing Audit Request")+"&body="+encodeURIComponent(body);
document.getElementById("msg").textContent="Opening your email app to send the request.";
});
var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add("in");io.unobserve(x.target)}})},{threshold:.12});
document.querySelectorAll(".rv").forEach(function(el){io.observe(el)});
