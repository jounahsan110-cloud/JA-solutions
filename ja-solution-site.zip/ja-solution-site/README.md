# JA Solution website

Static site, ready for GitHub Pages. No build step.

## Deploy
1. Upload everything in this folder to the root of a GitHub repository.
2. Repo **Settings > Pages > Build and deployment**: Source = *Deploy from a branch*, Branch = `main`, folder = `/ (root)`.
3. Open the URL GitHub shows (https://USERNAME.github.io/REPO/). All paths are relative, so it works on project sites and custom domains.

## Add your assets (no code changes needed)
| File | Where | Notes |
|---|---|---|
| Logo | `assets/images/logo.svg` (or `.png`, `.webp`, `.jpg`) | Detected automatically, shown unchanged in header and footer. Use a version that is visible on a dark background. |
| Favicon | replace `assets/icons/favicon.svg` | Keep the same filename. |
| Social share image | `assets/images/og-image.jpg` | About 1200x630. |
| Fonts | `assets/fonts/` | Site uses the visitor's system fonts for speed. |

## Edit
- Contact email: top of `js/main.js` (`EMAIL`).
- Colors: variables at the top of `css/style.css`.
- Optional SEO: after you know your live URL, add a `<link rel="canonical">` and a `sitemap.xml` with it.
